## Costum Owl Carousel

Screenshoot for the project
![costum owl carousel](./Carousel&#32;costum.png)